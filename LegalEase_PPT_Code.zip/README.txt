# LegalEase - PPT Code

This folder contains an HTML/CSS/JavaScript version of the LegalEase project presentation.

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Use the Previous/Next buttons or keyboard arrow keys.

## Project
LegalEase: AI-Powered Legal Document Generator
Team ID: SWTID-2026-3205
