const slides=[...document.querySelectorAll('.slide')];
let current=0;
const counter=document.getElementById('counter');
function show(n){current=(n+slides.length)%slides.length;slides.forEach((s,i)=>s.classList.toggle('active',i===current));counter.textContent=`${current+1} / ${slides.length}`;}
document.getElementById('next').onclick=()=>show(current+1);
document.getElementById('prev').onclick=()=>show(current-1);
document.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key===' ')show(current+1);if(e.key==='ArrowLeft')show(current-1);});
show(0);